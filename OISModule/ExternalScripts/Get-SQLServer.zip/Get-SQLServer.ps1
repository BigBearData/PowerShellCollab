﻿<#

	.SYNOPSIS
		Queries the registry of a computer an checks if a MS-SQL Server is installed.

	.DESCRIPTION
		Queries the registry of a computer an checks if a MS-SQL Server is installed. If it is so, the FileVersion from the sqlservr.exe is taken 
		and queried against the CSV file which includes _almost_ all MS-SQL Server .exe FileVersion and the EOL Dates.

		Contact me at http://nt-guys.de or kamil.kosek@nt-guys.de
		- Kamil Kosek
		
		Version history:
		1.0 (2014/03/21) -> Initial release

	.PARAMETER  $Computers
		You have to provide a single computername or an array of computernames.

	.EXAMPLE
		PS C:\> .\Get-SQLServer.ps1 -Computers "DB-Server"
		Queries the computer DB-Server 
		Output looks like:
		ServerName             : DB-Server
		InstanceName           : MSSQL.1
		Edition                : Enterprise Edition
		Version                : 9.2.3042.00
		FileVersion            : 2005.90.3077.0
		EndOfMainstreamSupport : 12.01.2010 00:00:00
		IsMainstreamSupported  : False
		EndOfExtendedSupport   : 12.01.2010 00:00:00
		IsExtendedSupported    : False
		KBArticle              : 960089 MS09-004: Description of the security update for SQL Server 2005 GDR: February 10, 2009
 
		
	.OUTPUTS
		psobject

	.NOTES
		Comment and vote it please.

	.LINK
		www.nt-guys.de
	.LINK

#>
param(
	$SQLBuildsCSV = ".\SQLServerBuilds.csv",
	[Parameter(Mandatory=$true,
		           ValueFromPipeline=$false,
		           HelpMessage='You have to provide a single computername or an array of computernames')]
		$Computers,
	$Date = $(Get-Date )
	
)
$SQLBuilds = Import-Csv $SQLBuildsCSV -Delimiter ";"
$i = 1
$ret = @()
foreach ($server in $Computers)
{
	Write-Progress -Activity "Gathering information" -Status "Current Server $($Server.name) ($i of $($computers.count))" -PercentComplete (($i/$Computers.Count) * 100) -ID 1
	$i++
	
	if (Test-Connection -ComputerName $server -Count 1 -Quiet)
	{
		$regKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $server)
		$SqlKey = $regKey.OpenSubKey("SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL")
		Write-Verbose "Processing Server $server"
		if ($SqlKey -ne $null)
		{
			Foreach ($instance in $SqlKey.GetValueNames())
			{
				$SQLServerObject = New-Object PSObject
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name ServerName -Value $server
				$InstanceName = $SqlKey.GetValue("$instance")
				Write-Progress -Activity "Parsing SQL-Server Information" -Status "Current Instance $instancename" -ParentID 1
				$InstanceKey = $regKey.OpenSubkey("SOFTWARE\Microsoft\Microsoft SQL Server\$InstanceName\Setup")
				$FileVersion = $($($(dir "\\$server\$($InstanceKey.GetValue("SQLBinRoot").ToString().Replace(":","$"))\sqlservr.exe").VersionInfo.FileVersion).Split(" ")[0] -replace "(?<!\d)0+(?=\d+)")
				$EndOfMainstreamSupport = $(Get-Date $($SQLBuilds | ? { $_.FileVersion -eq $FileVersion } | select EndOfMainstreamSupport).EndOfMainstreamSupport)
				$EndOfExtendedSupport = $(Get-Date $($SQLBuilds |? {$_.FileVersion -eq $FileVersion }|select EndOfExtendedSupport).EndOfExtendedSupport)
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name InstanceName -Value $InstanceName
				
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name Edition -Value $InstanceKey.GetValue("Edition")
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name Version -Value $InstanceKey.GetValue("Version")
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name FileVersion -Value $FileVersion
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name EndOfMainstreamSupport -Value $EndOfMainstreamSupport
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name IsMainstreamSupported -Value $(if((($date)-($EndOfMainstreamSupport)).Days -gt 0){$false}else{$true})
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name EndOfExtendedSupport -Value $EndOfExtendedSupport
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name IsExtendedSupported -Value $(if ((($date) - ($EndOfExtendedSupport)).Days -gt 0) { $false }else { $true })
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name KBArticle -Value $($SQLBuilds | ? { $_.FileVersion -eq $FileVersion } | select KB).KB
				$SQLServerObject
			}
			Write-Progress -Activity "Parsing SQL-Server Information" -Completed
			
		}
		else
		{
			Write-Warning -Message "The Server $server hasn´t SQL Server installed"
		}
	}
	else
	{
		Write-Error -Message "$server is not available"
	}
}

	

