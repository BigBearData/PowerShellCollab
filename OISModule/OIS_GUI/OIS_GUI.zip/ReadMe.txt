NB! This PowerShell script is for internal Omada use only.
This tool is not supported by Omada and is not meant to replace any official internal processes at Omada.